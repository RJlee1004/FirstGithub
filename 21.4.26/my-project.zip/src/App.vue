<template>
  <div id="app">
    <h2>{{ $store.students }}</h2>
    <button @click="updateInfo">修改</button>

    <h2>{{ $store.state.a.name }}</h2>
  </div>
</template>

<script>
export default {
  name: "App",
  methods: {
    updateInfo() {
      // this.$store.dispatch("aUpdateInfo", "我是payload");
      // this.$store.dispatch("aUpdateInfo", {
      //   msg: "我是携带的而信息",
      //   success: () => {
      //     console.log("里面已经完成");
      //   },
      // });
      this.$store
        .dispatch("aUpdateInfo", "我是携带的信息")
        .then((res) => {
          console.log("里面完成了提交");
          console.log(res);
        })
        .catch((err) => {
          console.log("出现了错误");
        });
    },
  },
};
</script>

<style>
</style>
