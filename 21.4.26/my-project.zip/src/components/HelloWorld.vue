<template>
  <div class="hellovuex"></div>
</template>

<script>
export default {
  name: "HelloVuex",
  data() {
    return {
      msg: "Vuex",
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
