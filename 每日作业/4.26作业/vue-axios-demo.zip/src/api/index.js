import home from "./home";

export default {
  home
};

/**
 * 全局使用方法: this.$api.home.post().then()
 */
