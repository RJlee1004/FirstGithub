import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import "./utils";
Vue.config.productionTip = false;

router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title;
  }
  next();
});

router.onError(error => {
  const pattern = /Loading chunk (\d)+ failed/g;
  const isChunkLoadFaild = error.message.match(pattern);
  const targetPath = router.history.pending.fullPath;
  if (isChunkLoadFaild) {
    router.replace(targetPath);
  }
  console.log("isChunkLoadFaild", isChunkLoadFaild, targetPath);
});

new Vue({
  router,
  render: h => h(App)
}).$mount("#app");
