<template>
  <div class="page">
    <div class="g-center">
      <h1>404~~</h1>
    </div>
  </div>
</template>
<script>
export default {
  name: "404",
  data() {
    return {};
  },
  mounted() {
  }
};
</script>
