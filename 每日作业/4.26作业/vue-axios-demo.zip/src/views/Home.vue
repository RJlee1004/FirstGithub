<template>
  <div class="home">
    <h1>0426-Home</h1>
  </div>
</template>

<script>
export default {
  name: "Home"
};
</script>

<style lang="less" scoped>
.home {
  font-size: 30px;
  height: 100%;
}
</style>
